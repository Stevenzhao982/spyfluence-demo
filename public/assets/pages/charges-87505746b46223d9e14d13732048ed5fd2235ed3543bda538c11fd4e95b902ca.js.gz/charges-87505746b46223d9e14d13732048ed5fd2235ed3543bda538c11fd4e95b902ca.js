$('#checkout_container_1').html("<%= escape_javascript(render 'checkout') %>");
