$('#first_step_container').html("<%= escape_javascript(render 'charges') %>");
