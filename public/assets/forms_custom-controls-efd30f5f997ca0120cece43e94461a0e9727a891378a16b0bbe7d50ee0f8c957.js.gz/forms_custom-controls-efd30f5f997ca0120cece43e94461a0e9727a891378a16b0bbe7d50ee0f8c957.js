$(function() {
  $('#indeterminate-checkbox').prop('indeterminate', true)
  $('#disabled-indeterminate-checkbox').prop('indeterminate', true)
});
