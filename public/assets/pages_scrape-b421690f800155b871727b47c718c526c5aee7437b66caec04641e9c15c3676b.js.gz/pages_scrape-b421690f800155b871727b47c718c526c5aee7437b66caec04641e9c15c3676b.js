$( "#followers" ).click(function() {
    alert($('#competitor').val())
});

$( "#following" ).click(function() {
    alert($('#competitor').val())
});
